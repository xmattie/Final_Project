//variable that will hold text output
var reading;

//controls the height of the text
var y = 0;

//preloads the text file
function preload() {
  //text file from node
  reading = loadStrings('reading.txt');
}

function setup() {
  createCanvas(1280, 620);
  frameRate(1); //makes the text scroll slower
}

function draw() {
  background(0);
  y = y += 100; //scrolls the text
  if (y >= height - 600) {
    y = 0;
  }
  //the lines of text
  tweet(y);
  tweet(y + 100);
  tweet(y + 200);
  tweet(y + 300);
  tweet(y + 400);
  tweet(y + 500);
  tweet(y + 600);
}

function tweet(y) { //grabs and displays tweets
  //randomizes the tweets by line
  var rawtext = floor(random(reading.length));
  fill(0, 255, 0);
  textAlign(CENTER);
  textSize(30);
  textFont("Courier");
  text(reading[rawtext], 640, y);
}