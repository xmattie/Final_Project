// Needed node.js modules
var fs = require('fs');
var Twit = require('twit');

// Pulls in my Twitter keys and tokens
// to deal with OAuth
var creds = require('./credentials');
var REST = new Twit(creds.test);

// Run: node twitterchart.js USERNAME
// Outputs "Scrying @USERNAME" when beginning
var targetUser = process.argv[2];
console.log('Scrying @' + targetUser)

// Takes out all the symbols and cleans up the text
function cleanStatus(status) {
  var toStrip = /RT |@\S+ ?|#\D+ ?|http\S+ ?/gi;
  var cleaned = status.replace(toStrip, '');
  return cleaned;
}

// Grabs the last 200 followed friends'
// most recent tweet
REST.get('friends/list', {screen_name: targetUser, count: 200}).
  then(res => {
    // Takes the list of users from the API response
    var friends = res.data.users;
    // Gets the most recent tweet from each friend
    // if they have one
    var statuses = friends.map(function(friend) {
      var text;
      if (friend.status) { 
        text =  friend.status.text;
      } else {
        text = '';
      }
      return text;
    });
    // Cleans up the statuses
    var cleanStatuses = statuses.map(function(status) {
      return cleanStatus(status)
    });
    // Compiles statuses into text for output
    var textOutput = cleanStatuses.join(". ");
    // Saves the statuses to a text file
    fs.writeFileSync(`reading.txt`, textOutput);
    // Displays the text
    console.log(textOutput);
  });
